from rest_framework import serializers
from examapi.models import Question,Users,Admin,Result

class QuestionSerilzer(serializers.ModelSerializer):
    

    class Meta:
        model=Question
        fields='__all__'

class UsersSerilzer(serializers.ModelSerializer):
    

    class Meta:
        model:Users
        fields='__all__'


class AdminSerilizer(serializers.ModelSerializer):
      
      class Meta:
            model=Admin
            fields='__all__'


class ResultSerilizers(serializers.ModelSerializer):
      
      class Meta:
            model=Result
            fields='__all__'           
