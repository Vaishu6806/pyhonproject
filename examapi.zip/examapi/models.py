from django.db import models


# Create your models here. 

class Users(models.Model):
    username=models.CharField(max_length=40,primary_key=True)
    password=models.CharField(max_length=40)
    mobno=models.IntegerField()
    emailid=models.CharField(max_length=100)

    def __str__(self):
        return f"{self.username},{self.password},{self.mobno},{self.emailid}"

    class Meta:
        db_table="users"

class Question(models.Model):
    qno=models.IntegerField(primary_key=True)
    qtext=models.CharField(max_length=255) 
    answer=models.CharField(max_length=255)
    op1=models.CharField(max_length=255)
    op2=models.CharField(max_length=255)
    op3=models.CharField(max_length=255)
    op4=models.CharField(max_length=255)
    subject=models.CharField(max_length=255)

    class Meta:
        db_table='Question'

class Result(models.Model):

     username=models.CharField(max_length=40,default='',primary_key=True)
     subject=models.CharField(max_length=40,default='null')
     score = models.IntegerField()

     def __str__(self):
          return "{},{},{}".format(self.username,self.subject,self.score)
     
     class Meta:
          db_table="result"

class Admin(models.Model):
     username=models.CharField(max_length=40,default='',primary_key=True)
     password=models.CharField(max_length=40,default='')
     
     def __str__(self):
          return "{},{},{},{}".format(self.username,self.password)

     class Meta:
          db_table="admin"

        




