from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.db import connection
from examapi.models import Users,Question,Admin,Result
from examapi.serilizers import QuestionSerilzer,ResultSerilizers



# Create your views here.

@api_view(['post'])
def validate(request):
    userfromclint=request.data
    userfromdb=Users.objects.get(username=userfromclint["username"])

    if userfromclint["username"]==userfromdb.username and userfromclint["password"]==userfromdb.password:
        return Response(True)
    else:
        return Response(False) 

@api_view(['post'])
def validate2(request):
    userfromclient=request.data   # data coming from browser while log in
    print(userfromclient)
    userfromdb=Admin.objects.get(username=userfromclient["username"])
    

    # username   password   mobno   emailid 
    # x          y          123     x@123     data from the database


    if userfromclient["username"]==userfromdb.username and userfromclient["password"]==userfromdb.password:
        return Response(True) # response will be given to angular and then angular will show question page
    else:
        return Response(False) # response will be given to angular and then angular will show login page with error message
        

@api_view(['GET'])
def getAllQuestions(request,subject):
    allquestions=Question.objects.filter(subject=subject)
    serilizer=QuestionSerilzer(allquestions,many=True)
    
    return Response(serilizer.data)

@api_view(['GET'])
def viewQuestion(request,qno,subject):

    question=Question.objects.get(qno=qno,subject=subject)
    
    return Response(QuestionSerilzer(question).data)

@api_view(['POST'])
def addQuestion(request):
    question=request.data

    Question.objects.create(qno=question["qno"],subject=question["subject"],answer=question["answer"],qtext=question["qtext"],op1=question["op1"],op2=question["op2"],op3=question["op3"],op4=question["op4"])

    return Response(True)

@api_view(['PUT'])
def updateQuestion(request):

    question=Question.objects.filter(qno=request.data["qno"],subject=request.data["subject"])

    question.update(qtext=request.data["qtext"],answer=request.data["answer"],op1=request.data["op1"],op2=request.data["op2"],op3=request.data["op3"],op4=request.data["op4"])

    print(connection.queries)
    return Response(True)
    
     

@api_view(['DELETE'])
def deleteQuestion(request,qno,subject):
    
   queryset=Question.objects.filter(qno=qno,subject=subject)

   queryset.delete()

   return Response(True) 



@api_view(['post'])
def saveResult(request):

    print(request.data)

    serilizer=ResultSerilizers(data=request.data)

    if serilizer.is_valid():
        print(connection.queries)
        serilizer.save()
        
    return Response(request.data) 


@api_view(["GET"])
def getResults2(request,subject,pageno):

    print("given subject is  " + str(len(subject)))

    myresult=Result.objects.filter(subject=subject)

    print(myresult.query)

    noofrecords=myresult.__len__()
    
    print("no of records are " + str(noofrecords))
    
    # how many pages are required to show results

    pagenumber = 1#4

    while (3 * pagenumber) < noofrecords:
        pagenumber += 1

    
    indexlist = list() #[]

    count=0

    print("pagenumber is " , str(pagenumber))

    for i in range(0,pagenumber):
         indexlist.append(count)
         count = count + 3
    
    print(indexlist)
    
    startindex=indexlist[int(pageno)-1]

    allrecords=list(Result.objects.filter(subject=subject))

    if pageno==pagenumber:
           totalrecordsshown = 3 * (pagenumber - 1)
           recordstoshow = noofrecords - totalrecordsshown
           endindex=startindex+recordstoshow

           allresults=allrecords[startindex:endindex]
           serilizer=ResultSerilizers(allresults,many=True)
           return Response(serilizer.data)
           
    else:
          endindex=startindex+3
          allresults=allrecords[startindex:endindex]
          serilizer=ResultSerilizers(allresults,many=True)
          return Response(serilizer.data)
    

    
@api_view(["GET"])
def getResults(request,subject):
    allresults=Result.objects.filter(subject=subject)
    serilizer=ResultSerilizers(allresults,many=True)
    return Response(serilizer.data)


@api_view(["GET"])
def getRecordsCounts(request,subject):

    count=Result.objects.filter(subject=subject).__len__()
    return Response(count)

@api_view(['GET'])
def getAllSubjects(request):

    # allquestions=Question.objects.all()

    # mapresult=map(lambda question:question.subject,allquestions)

    # return Response(set(mapresult))
     
    #specific field  data

    listofsubjects=Question.objects.all().values('subject')
    
    print(listofsubjects)
    
    subjects=[]

    for dictionary in listofsubjects:
         
         for value in dictionary.values():
              subjects.append(value)
         
    return Response(set(subjects))