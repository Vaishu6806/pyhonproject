from django.urls import path,include
from. import views


urlpatterns=[
    path('validate/',views.validate),

    path('validate2/',views.validate2),

    path('getAllQuestions/<subject>',views.getAllQuestions),

    path('viewQuestion/<qno>/<subject>',views.viewQuestion),

    path('addQuestion/',views.addQuestion),

    path('updateQuestion/',views.updateQuestion),

    path('deleteQuestion/<qno>/<subject>',views.deleteQuestion),

    path('saveResult/',views.saveResult),

    path('getResults/<subject>',views.getResults),

    path("getRecordsCounts/<subject>",views.getRecordsCounts),
    
    path('getResults2/<subject>/<pageno>',views.getResults2),

    path('getAllSubjects/',views.getAllSubjects),


]